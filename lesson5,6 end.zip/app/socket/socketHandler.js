const socketIO = require("socket.io");
const formatMessages = require("../utils/messages");

const initializeSocket = (server) => {
  const io = socketIO(server);
  io.on("connection", (socket) => {
    socket.emit("message", formatMessages("BOT", "welcome!"));
    socket.broadcast.emit(
      "message",
      formatMessages("BOT", "A user just connected!")
    );

    socket.on("chatMsg", (m) => {
      io.emit("message", formatMessages("USER", m));
    });

    socket.on("disconnect", () => {
      io.emit("message", formatMessages("BOT", "A user has just left!"));
    });
  });
};
module.exports = initializeSocket;
